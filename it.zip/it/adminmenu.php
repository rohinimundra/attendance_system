<div id='toparea'>
            
          <div id="tabs">
		<ul>
		 
		  <li><a id="m1" href="portal.php"><span style="background-color:#930;">Dashboard</span></a></li>
                  <li><a id="m2" href="view_employee.php"><span>View Employee</span></a></li>
                 <li><a  id="m3" href="addemp.php"><span>Add Employee</span></a></li>
                  <li><a  id="m4" href="upemp.php"><span>Update Employee</span></a></li>
                   <li><a id="m5" href="delemp.php"><span>Delete Employee</span></a></li>
		</ul>
</div> <!--END tab-->