<?php
function send_attachment($mailto, $message, $filename) {
	$from_mail="erashraful@gmail.com";
	$from_name="Ashraful Alom";
	$subject="This is a mail with attachment.";
	$replyto="info@ashrafulalom.com";
	$path="./";
	$file = $path.$filename;
	
    $file_size = filesize($file);
    $handle = fopen($file, "r");
    $content = fread($handle, $file_size);
    fclose($handle);
    $content = chunk_split(base64_encode($content));
    $uid = md5(uniqid(time()));
    $header = "From: ".$from_name." <".$from_mail.">\r\n";
    $header .= "Reply-To: ".$replyto."\r\n";
    $header .= "MIME-Version: 1.0\r\n";
    $header .= "Content-Type: multipart/mixed; boundary=\"".$uid."\"\r\n\r\n";
    $header .= "This is a multi-part message in MIME format.\r\n";
    $header .= "--".$uid."\r\n";
    $header .= "Content-type:text/plain; charset=iso-8859-1\r\n";
    $header .= "Content-Transfer-Encoding: 7bit\r\n\r\n";
    $header .= $message."\r\n\r\n";
    $header .= "--".$uid."\r\n";
    $header .= "Content-Type: application/octet-stream; name=\"".$filename."\"\r\n"; // use different content types here
    $header .= "Content-Transfer-Encoding: base64\r\n";
    $header .= "Content-Disposition: attachment; filename=\"".$filename."\"\r\n\r\n";
    $header .= $content."\r\n\r\n";
    $header .= "--".$uid."--";
    
    $receiver_mail = explode(',',$mailto); //print_r($receiver_mail); die();
    foreach ($receiver_mail as $email) {
    	if(mail($email, $subject, "", $header));
    	else die("Error in Sending mail !!!");
    }   echo "Message sent Successfully!";
}	//End of send_attachment()
/*
$my_file = "abc.pdf";
$my_name = "Ashraful Alom";
$my_mail = "ashraful@avantikain.com, skalomcs@gmail.com";
$my_message = "Hello,\r\n Please download the attachment file.\r\n\r\n Thank You";
send_attachment("ashraful@avantikain.com,skalomcs@gmail.com", $my_message, $my_file);
*/
