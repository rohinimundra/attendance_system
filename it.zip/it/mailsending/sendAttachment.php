<?php
function send_attachment($emails,$msg,$attachment) {
        $sender_name=""; //$_POST["sender_name"];
        $sender_email=""; //$_POST["sender_email"];
        //$receiver_mail=$email; //$_POST["email"];
        
        $receiver_mails=$emails;
        $receiver_mail = explode(',',$emails);
        
        $subject="New subscription mail"; //$_POST["subject"];
        $message=$msg; //$_POST["message"];
        
        require_once('phpmailer/PHPMailerAutoload.php');
        $mail = new PHPMailer;
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'kamalthakuria12@gmail.com';## gmnail user name
        $mail->Password = 'kamal@#$12'; ## gmail Password
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;
        $mail->FromName = $sender_name;
        $mail->From = $sender_email;
        //$mail->AddAddress($receiver_mail);
        foreach ($receiver_mail as $email) {
            $mail->AddAddress( trim($email));
        }
        $mail->addReplyTo($sender_email, 'Reply Address');
        $mail->WordWrap = 50;
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $message;
        $mail->AddAttachment($attachment);      // attachment
        if($mail->send()) $result=1;
        else $result=0;
        return $result;
}   //End of send_attachment()


?>
