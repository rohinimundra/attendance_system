<?php
function send_mail($email,$sub,$msg) {
        $sender_name="Kamal"; //$_POST["sender_name"];
       // $sender_email="info@avantikain.com"; //$_POST["sender_email"];
        $sender_email="kamalthakuria143@gmail.com";
        $receiver_mail=$email; //$_POST["email"];
        $subject=$sub; //$_POST["subject"];
        $message=$msg; //$_POST["message"];
        
        require_once('phpmailer/PHPMailerAutoload.php');
        $mail = new PHPMailer;
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'kamalthakuria143@gmail.com';
        $mail->Password = 'kamal@#$123';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;
        $mail->FromName = $sender_name;
        $mail->From = $sender_email;
        $mail->AddAddress($receiver_mail);
        $mail->addReplyTo($sender_email, 'Reply Address');
        $mail->WordWrap = 50;
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $message;
        if($mail->send()) $result=1;
        else $result=0;
        return $result;
}   //End of send_msg()

//Current Server path
$path = (@$_SERVER["HTTPS"] == "on") ? "https://" : "http://";
$path .=$_SERVER["SERVER_NAME"]. dirname($_SERVER["PHP_SELF"]); 
?>
