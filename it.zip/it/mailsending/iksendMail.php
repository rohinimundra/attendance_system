<?php
	/**
	 * This example shows settings to use when sending via Google's Gmail servers.
	 */
	//SMTP needs accurate times, and the PHP time zone MUST be set
	//This should be done in your php.ini, but this is how to do it if you don't have access to that
	date_default_timezone_set('Etc/UTC');

	//require '../PHPMailerAutoload.php';
	require_once('phpmailer/PHPMailerAutoload.php');

	//-----------------------------------------------------
	/*$sender_name="reebanv"; //$_POST["sen_name"];
	$sender_email="reebanv25@gmail.com"; //$_POST["sen_email"];
	
	$receiver_mails=$emails; //$_POST["email"];
	$receiver_mail = explode(',',$emails);
	
	$subject="New subscription mail"; //$_POST["subject"];
	$message=$msg; //$_POST["message"];*/
	echo "";
	
	$sen_name = "";
	$sen_email = "";
	$rec_email = "";
	$email_sub = "";
	$box_msg = "";
	$attachfile=""; $attachfileName="";
	
	// Retrieving & storing user's submitted information
	if (isset($_POST['sen_name'])) { $sen_name = $_POST['sen_name']; }
	if (isset($_POST['sen_email'])) { $sen_email = $_POST['sen_email']; }
	if (isset($_POST['rec_email'])) { $rec_email = $_POST['rec_email']; }
	if (isset($_POST['email_sub'])) { $email_sub = $_POST['email_sub']; }
	if (isset($_POST['box_msg'])) { $box_msg = $_POST['box_msg']; }
	
	if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] == UPLOAD_ERR_OK) {
		$attachfile=$_FILES['attachment']['tmp_name'];
		$attachfileName=$_FILES['attachment']['name'];
		//$mail->AddAttachment($_FILES['uploaded_file']['tmp_name'], $_FILES['uploaded_file']['name']);
	}

	$email_sub = 'PHPMailer GMail SMTP test';
	//$box_msg = 'This is a plain-text message body';
	
	//echo "Upload file: " . $sen_email;
	//-----------------------------------------------------
	
	//Create a new PHPMailer instance
	$mail = new PHPMailer;

	//Tell PHPMailer to use SMTP
	$mail->isSMTP();
	
	//Enable SMTP debugging
	// 0 = off (for production use)
	// 1 = client messages
	// 2 = client and server messages
	$mail->SMTPDebug = 0;
	
	//Ask for HTML-friendly debug output
	$mail->Debugoutput = 'html';
	
	
	//Set the hostname of the mail server
	$mail->Host = 'smtp.gmail.com';
	// use
	// $mail->Host = gethostbyname('smtp.gmail.com');
	
	//Whether to use SMTP authentication
	$mail->SMTPAuth = true;
	
	// if your network does not support SMTP over IPv6
	//Set the SMTP port number - 587 for authenticated TLS, a.k.a. RFC4409 SMTP submission
	$mail->Port = 465; //587;	//465;
	
	//Set the encryption system to use - ssl (deprecated) or tls
	$mail->SMTPSecure = 'ssl'; //'tls';
	
	//Username to use for SMTP authentication - use full email address for gmail
	$mail->Username = "kamalthakuria12@gmail.com";
	//Password to use for SMTP authentication
	$mail->Password = "kamal@#$12";
	
	
	//Set who the message is to be sent from
	$mail->setFrom($sen_email, $sen_name);
	
	//Set an alternative reply-to address
	$mail->addReplyTo($sen_email, $sen_name);
	
	//Set who the message is to be sent to
	$mail->addAddress('rajujorhat46@gmail.com', 'Raju(R)');
	$mail->addAddress($rec_email, 'Raju');
	
	//Set the subject line
	$mail->Subject = $email_sub; //'PHPMailer GMail SMTP test';
	
	//Read an HTML message body from an external file, convert referenced images to embedded,
	//convert HTML into a basic plain-text alternative body
	////$mail->msgHTML(file_get_contents('contents.html'), dirname(__FILE__));
	
	//Replace the plain text body with one created manually
	//$mail->AltBody = $box_msg; //'This is a plain-text message body';
	
	$mail->Body    = 'This is the following documents<b></b>';
	$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
	
	//Attach an image file
	$mail->addAttachment($attachfile, $attachfileName);
	
	//send the message, check for errors
	if (!$mail->send()) { 
		echo "Mailer Error: " . $mail->ErrorInfo;
	} else {
		echo ("<SCRIPT LANGUAGE='JavaScript'>
          window.alert('Successfully Inserted')
        window.location.href='it/career.html'
        </SCRIPT>");
    exit;
	}
?>