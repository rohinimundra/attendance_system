<?php
function send_mail($email,$sub,$msg){
    $to=$email; //Receiver(s)
    $header="From:"."KAMAL"."<"."kamalthakuria143@gmail.com".">"."\r\n";
    $subject = $sub;
    $sentmail = mail($to,$subject,$msg,$header);
    if($sentmail) $msg=1;
    else $msg= 0;
    return $msg;			
} //End of send_msg()

?>
